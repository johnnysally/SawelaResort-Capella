npm install to add all dependancies
# my-v0-project

A modern web project built with **Next.js 14**, **React 18**, **TailwindCSS 4**, and UI components powered by **Radix UI**, **Lucide Icons**, and more.  
It also includes support for **TypeScript**, **form validation with Zod**, and **data handling with React Hook Form**.

---

## 🚀 Features
- ⚡ Next.js 14 with React 18  
- 🎨 TailwindCSS 4 with animations (`tailwindcss-animate`, `tw-animate-css`)  
- 🧩 Radix UI components (dialogs, menus, tooltips, forms, etc.)  
- 📝 Form handling with React Hook Form + Zod validation  
- 📊 Charts with Recharts  
- 🎠 Embla Carousel integration  
- 🌗 Dark mode with `next-themes`  
- 📦 Ready for TypeScript  
- 🔍 Built-in linting (`next lint`)  
- 📈 Analytics with Vercel Analytics  

---

## 📦 Requirements
To run this project locally, make sure you have:

- **Node.js** ≥ 18 (recommended: latest LTS)  
- **npm** (comes with Node.js) or **yarn**  
- A modern browser (Chrome, Edge, Firefox, Safari)  
- (Optional) **Git** for cloning the repository  

---

## 🛠 Installation

Clone the repository:
npm run dev


```bash
git clone https://github.com/your-username/my-v0-project.git
cd my-v0-project
npm run dev
